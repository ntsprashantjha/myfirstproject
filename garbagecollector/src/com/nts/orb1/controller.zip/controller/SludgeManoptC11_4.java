package com.nts.orb1.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.json.JSONException;
import org.json.JSONObject;

import com.nts.grb.connection.JsonObj;
import com.nts.grb.service.GetUserMacId;
import com.nts.grb.validation.ActiveUserStatus;
import com.nts.grb.validation.ReturnResponse;
import com.nts.mrb.dao.GetShipTimeZone;
import com.nts.orb1.dao.SoftwareLicenceTime;
import com.nts.orb1.service.CurrentQuanityUpdation;
import com.nts.orb1.service.MasterTable;
import com.nts.orb1.util.HibernateUtil;

/**
 * Servlet implementation class SludgeManoptC11_4
 */
@WebServlet("/SludgeManoptC11_4")
public class SludgeManoptC11_4 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger logger = Logger.getLogger(SludgeManoptC11_4.class);

	
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SludgeManoptC11_4() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		JSONObject jObj = new JsonObj().get_btn_num(request, response);
		System.out.println("**json data from modal operation controller**" + jObj);

		String stringDate = null;
		logger.setLevel(Level.ERROR.FATAL.INFO.WARN);
		PrintWriter out = response.getWriter();

		if (new SoftwareLicenceTime().remainTime() < 0) {

			out.print(ReturnResponse.licenceExpire());

		}

		else {

			if (ActiveUserStatus.userstatus(GetUserMacId.getClientMACAddress(request)) == 0) {

				System.out.println("****when user is not looged in***");
				out.print(ReturnResponse.retrnresponse_url());
			}

			else {

				try {
					String timezone = GetShipTimeZone.gettimezone();

					com.nts.orb1.model.SludgeC11_4Orb1 manualOpt_11_4 = new com.nts.orb1.model.SludgeC11_4Orb1();
					manualOpt_11_4.setOfficer_id(
							com.nts.grb.query.ActiveUserInfo.activeUserId(GetUserMacId.getClientMACAddress(request)));

					String[] stopdate = jObj.getString("stop_date").split("T");
					String[] startdate = jObj.getString("start_date").split("T");

					manualOpt_11_4.setStart_date(startdate[0]);
					manualOpt_11_4.setStop_date(stopdate[0]);

					manualOpt_11_4.setDestination_tank(jObj.getString("tank_name"));
					manualOpt_11_4.setQuantity_transferred(jObj.optDouble("qty_transfered"));

					manualOpt_11_4.setQuan_ret_des_tank(jObj.getDouble("qty_retained"));
					manualOpt_11_4.setRemark("");
					manualOpt_11_4.setSource(jObj.getString("source"));

					MasterTable mstrObj = new MasterTable();
					manualOpt_11_4.setEntry_id(mstrObj.lastEntry());

					Session session = HibernateUtil.buildSessionFactory().openSession();
					Transaction tran = session.beginTransaction();

					session.save(manualOpt_11_4);
					tran.commit();

					mstrObj.lastEntryUpdation("mannual opertion C_11.4", jObj.getString("start_date"), "", 0, timezone,
							startdate[0]);
					new CurrentQuanityUpdation().currentQuantity(jObj.getString("tank_name"),jObj.getDouble("qty_retained"));
					out.print(ReturnResponse.success_condition());

				}

				catch (SQLException e) {

					logger.error(e.getMessage());
					e.printStackTrace();
					out.print(ReturnResponse.retrnresponse_db_error());
				}

				catch (JSONException e) {

					logger.error(e.getMessage());
					out.print(ReturnResponse.retrnresponse_wrong_json());
					e.printStackTrace();

				}
				out.print(ReturnResponse.success_condition());
			}
		}

	}

}
